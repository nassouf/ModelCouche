package app.controlleur;

import app.entites.Personne;
import app.ihm.PersonneUI;
import app.service.PersonneCalcul;

public class Personnecontro {
	PersonneCalcul personneCalcul = new PersonneCalcul();
	public Personnecontro(PersonneCalcul personneCalcul) {
		super();
		this.personneCalcul = personneCalcul;
	}

	public void init() {
		Personne p=PersonneUI.saisir();
		personneCalcul.CalculAge(p);
	}
}
