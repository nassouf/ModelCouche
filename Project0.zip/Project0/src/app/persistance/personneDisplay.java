package app.persistance;

import app.entites.Personne;

public class personneDisplay {
	public static void display(Personne p) {
		System.out.println("votre nom est "+p.getName());
		System.out.println("votre age est"+p.getAge());
	}

}
