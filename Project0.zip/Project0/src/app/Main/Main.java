package app.Main;
import app.controlleur.Personnecontro;
import app.service.PersonneCalcul;

public class Main {

	public static void main(String[] args) {
		Personnecontro pc=new Personnecontro(new PersonneCalcul());
		pc.init();
		// TODO Auto-generated method stub

	}

}
