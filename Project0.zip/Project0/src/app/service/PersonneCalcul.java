package app.service;

import app.entites.Personne;
import app.persistance.personneDisplay;

public class PersonneCalcul {
	public  void CalculAge(Personne p) {
		Personne p1=new Personne(p.getName(), p.getAge()+10);
		personneDisplay.display(p1);
	}

}
