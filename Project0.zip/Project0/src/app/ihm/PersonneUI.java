package app.ihm;

import java.util.Scanner;

import app.entites.Personne;

public class PersonneUI {
	public  static Personne saisir() {
		Scanner sc =new Scanner(System.in);
		System.out.println("donner votre nom");
		String nom=sc.next();
		System.out.println("donner votre age");
		int age=sc.nextInt();
		sc.close();
		return new Personne(nom, age) ;
		
		
		
	}
}
